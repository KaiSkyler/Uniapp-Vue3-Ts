declare namespace User {
  interface UserInfo {
    token: string
    user_id: Number
  }
}
