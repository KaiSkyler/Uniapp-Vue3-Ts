export const APP_NAME = '好食期';
export const APP_ID = 'xxxxx';
export const APP_VERSION = '1.0.0';
